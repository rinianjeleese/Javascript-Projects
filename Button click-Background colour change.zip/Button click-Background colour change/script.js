// document.getElementById("Primary").addEventListener('click',function name(params) {
//     document.getElementById('bgcolor').style.backgroundColor='red';
// })


// document.getElementById("Secondary").addEventListener('click',function name(params) {
//     document.getElementById('bgcolor').style.backgroundColor='purple';
// })


// document.getElementById('Success').addEventListener('click',function name(params) {
//     document.getElementById('bgcolor').style.backgroundColor='#FFFF66';
// })

// document.getElementById('Danger').addEventListener('click',function name(params) {
//     document.getElementById('bgcolor').style.backgroundColor='#0cda0cff';
// })

// document.getElementById('Warning').addEventListener('click',function name(params) {
//     document.getElementById('bgcolor').style.backgroundColor='#ebb00fff';
// })

// document.getElementById('Info').addEventListener('click',function name(params) {
//     document.getElementById('bgcolor').style.backgroundColor='#4a0cdaff';
// })

// document.getElementById("Random").addEventListener('click',function name(params) {
//     const red=Math.round(Math.random()*255);
//     const green=Math.round(Math.random()*255);
//     const blue=Math.round(Math.random()*255);

//     const color=`rgb(${red},${green},${blue})`;
//     document.getElementById("bgcolor").style.backgroundColor=color;

// })



//let body= document.getElementsByTagName("body");


function setColor(name) {
    document.getElementsByTagName('body')[0].style.backgroundColor=name;
}


function randomColor() {
    const red=Math.round(Math.random()*255);
    const green=Math.round(Math.random()*255);
    const blue=Math.round(Math.random()*255);

    const color=`rgb(${red},${green},${blue})`;
    document.getElementById("bgcolor").style.backgroundColor=color;
}

