//  // Generate random number
//  let randomNumber=Math.trunc(Math.random()*20)+1;
//  let score =20;
//  let highscore=0;
//   console.log("Random Number:",randomNumber);

// //Input Value
// document.querySelector('.check').addEventListener('click', function name(params) {

// const inputValue=Number( document.getElementById("myInput").value);
// console.log(inputValue);

// if(inputValue === randomNumber){
// document.getElementById("correctNumber").textContent="🎊 Correct Number";
// document.getElementById('questionChange').textContent=randomNumber;
//  if (score>highscore) {
//     highscore=score;
//     document.getElementById('highScore').textContent=highscore;
//  }
//  document.querySelector('body').style.backgroundColor="green";

// }else if (!inputValue) {
//     document.getElementById("correctNumber").textContent="⛔ No Number";

// }

// else if (inputValue>randomNumber) {
//     if (score>0) {

//     document.getElementById("correctNumber").textContent=" 📈 Too high! ";
//     score--;
//     document.getElementById('score').textContent=score;
//     }else{

//         document.getElementById("correctNumber").textContent="You lost the game !";
//         document.getElementById('score').textContent=0;
//     }

// }

// else {
//     if(score>0){
//     document.getElementById("correctNumber").textContent="📉 Too low!";

//     score--;
//     document.getElementById('score').textContent=score;
//     }else{

//         document.getElementById("correctNumber").textContent="You lost the game !";
//         document.getElementById('score').textContent=0;
//     }
// }
// })

// document.querySelector('#Again').addEventListener('click',function refresh() {

//     document.getElementById('myInput').value = "";

//     document.getElementById('score').textContent=20;
//     document.getElementById('highScore').textContent=highscore;
//    })



//Avoid duplication of code



function displayMessage (message){
   document.getElementById("correctNumber").textContent = message
}
//GEnerate Random NUmber
let randomNumber = Math.trunc(Math.random() * 20) + 1;
let score = 20;
let highscore = 0;
console.log("Random Number:", randomNumber);
//Input Value
document.querySelector('.check').addEventListener('click', function name(params) {

const inputValue=Number( document.getElementById("myInput").value);
console.log(inputValue);

if(inputValue === randomNumber){
displayMessage("🎊 Correct Number")
document.getElementById('questionChange').textContent=randomNumber;
 if (score>highscore) {
    highscore=score;
    document.getElementById('highScore').textContent=highscore;
 }
 document.querySelector('body').style.backgroundColor="green";

}else if (!inputValue) {
displayMessage("⛔ No Number")
} else if(inputValue!==randomNumber){
       if (score>0) {

    document.getElementById("correctNumber").textContent= `${inputValue>randomNumber ? ( "📈 Too High") : ("📉 Too Low")}`;
    score--;
    document.getElementById('score').textContent=score;
    }else{

        displayMessage("You lost the game !");
        document.getElementById('score').textContent=0;
    }
}
})

// else if (inputValue>randomNumber) {
//     if (score>0) {

//     document.getElementById("correctNumber").textContent=" 📈 Too high! ";
//     score--;
//     document.getElementById('score').textContent=score;
//     }else{

//         document.getElementById("correctNumber").textContent="You lost the game !";
//         document.getElementById('score').textContent=0;
//     }

// }
// //Input Number too low
// else {
//     if(score>0){
//     document.getElementById("correctNumber").textContent="📉 Too low!";

//     score--;
//     document.getElementById('score').textContent=score;
//     }else{

//         document.getElementById("correctNumber").textContent="You lost the game !";
//         document.getElementById('score').textContent=0;
//     }
// }
// })
//Again Button
document.querySelector('#Again').addEventListener('click',function refresh() {

    document.getElementById('myInput').value = "";
    document.getElementById('score').textContent=20;
    document.getElementById('highScore').textContent=highscore;
    document.getElementById('questionChange').textContent="❓"
   })

