let count=50;
console.log(typeof(count))
document.getElementById("counterLabel").textContent=count;
//increment Button
document.getElementById('increment').addEventListener("click", function name(params) {
    
    
    count=count+1;
    console.log(count);
    
    document.getElementById('counterLabel').textContent=count;
})
//decrement Button
document.getElementById('decrement').addEventListener("click", function name(params) {
    
    
    count=count-1;
    console.log(count);
    
    document.getElementById('counterLabel').textContent=count;
})
//Reset Button
document.getElementById('reset').addEventListener("click", function name(params) {
    
    
    count=0;
    console.log(count);
    
    document.getElementById('counterLabel').textContent=count;
})