let num1 = ""
let operatorSymbol = "";
let num2 = "";


//Function for Clicking value
function Press(value) {
    console.log(value);
    
     
    //  Building First number: If operator symbol is a null value, we have to save the value to num1.
     if (operatorSymbol==="") {
        
        num1+=value; //for example:If the value is a two digit number ie 78, concating 7 and 8 to get 78
        display(num1);//calling display function
         }
    //Building second number ((operatorSymbol!=="")): If operator symbol is not a null value, we have to save the value to num2. 
        else {
         num2+=value;
         display(num2)//calling display function
     }
    
     
}

//Function for  Displaying Operator

    function displayOp(operator) {
        console.log(operator); 
        if(num1!==""){
            operatorSymbol = operator          
            display(operatorSymbol);  //calling display function
        }
        else{
            display(""); // calling display function
        }
        

             
        }
        console.log(operatorSymbol);
        

//Function for  Calculation
function calculate(){
    let result=0;
    //Converting string to number
    num1=Number(num1);
    num2=Number(num2);
    //Doing Clculation = symbol
   switch(operatorSymbol){
    case '+':
        result=num1+num2;
        console.log(`${num1}+${num2}=${result}`);
        break;
    case '-':
        result=num1-num2;
        console.log(`${num1}-${num2}=${result}`);
        break;
    case '/':
        result=num2!==0?num1/num2:"Error";
        console.log(`${num1}/${num2}=${result}`);
        break;
    case '*':
        result=num1*num2;
        console.log(`${num1}*${num2}=${result}`);
        break;
    default:
        console.log("Error");
        break;
       
       
       
}
 //Displaying result
 if(result===0){
    display(""); //calling display function
 }
 else{
    num1=result;
    num2="";
    operatorSymbol=""
    display(result); //calling display function


 }
}



// Function to Clear Screen
function Clear(clear) {
    num1="";
    num2="";
    operatorSymbol="";
    display(""); //calling display function
}

console.log(num1);
console.log(num2);
//console.log(result);
console.log(operatorSymbol);


//Function display is created
function display(value) {
    document.getElementById('display').value = value;
}