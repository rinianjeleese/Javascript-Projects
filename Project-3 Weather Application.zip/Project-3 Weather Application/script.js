

let city=document.getElementById("cityInput")
let country= document.getElementById("cityDisplay")
let tem=document.getElementById("temperature")
let condition= document.getElementById("conditions")
let humidity=document.getElementById("humidity")
let wind= document.getElementById("windSpeed")

let image=document.getElementById("imgID")

const dialog=document.getElementById("dialogBox");


    

document.getElementById("searchButton").addEventListener("click",function name(params) {
   const location=city.value;
    fetchWeather(location)
})
const fetchWeather = (location)=> {
console.log(location);

let apiKey = "d432cc7ab6846dedd72d7b49fa33a5e9"


 fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}`).then((response) => response.json()).then(data=>{
    country.textContent=data.name;
    tem.textContent=data.main.temp;
    condition.textContent=data.weather[0].description;
    humidity.textContent=data.main.humidity;
    wind.textContent=data.wind.speed;


 
 switch (data.weather[0].description) {
     case "clear sky":
        image.src="weather/sunny.jpg"
         break;
        case  "rain":
        image.src="weather/rainy.jpg"
         break;
        case "thunderstorm":
        image.src="weather/thunderstorm.jpg"
         break;
        case "snow":
        image.src="weather/snowy.jpg"
         break;
        case "mist":
        image.src="weather/Foggy.jpg"
         break;

     default:
        image.src="weather.jpg"
         break;
    }

 }).catch((error) =>  console.log(error));

if (location==="") {
    document.getElementById("searchButton").addEventListener("click",function name(params) {
    dialog.style.display='block';
 
} )
}
 //(data=>console.log(data) )

//data=>{country.textContent=data.name;tem.textContent=data.main.temp;condition.textContent=data.weather[0].description;humidity.textContent=data.main.humidity;wind.textContent=data.wind.speed}) 
// .then(response=>response.json).then(data=>{}).catch(error=>console.log("Error",error));


}